LIVE-PHP-EDITOR (LPE)
=========

LPE is a ACE Editor Based Live PHP fiddle.

  - It's only for localhost
  - It use Eval to Execute code
 

Version
----

0.1


Installation
--------------

Just clone into you local server and then write and run your code from browser.


License
----

GPL v 3


**Free Software, Hell Yeah!**

[Ace Editor]:http://ace.ajax.org
[jQuery]:http://jquery.com

